# Validation Report — Univers-Cité Catho v2.0.0

```text
VALID
world_key: univers-cite-catho
pack_version: 2.0.0
concepts: 99
uckk_course_blueprints: 16
assessment_cases: 57
ethikos_topics: 15
```

## Checks performed

- `kx-world-pack/v1` manifest shape and semver.
- Required ethiKos v3 scenario and topic/category references.
- Kristal concept references used by all 16 UCKK blueprints exist in the source-derived 99-theme index.
- Knowledge resource type enum restricted to `article`, `video`, `lesson`, `quiz`, `dataset`.
- CertifiKation path threshold fixed at 80% and assessment references resolve to the 57 source cases.
- Crosslinks resolve to existing course blueprints.
- Base seed contains no unsourced artist religious-affiliation records or real Catholic-institution claims.

This is pack-level validation. Runtime materialization of non-ethiKos sidecars still requires the Konnaxion multi-module bridge/materializers documented by the existing Worlds.
