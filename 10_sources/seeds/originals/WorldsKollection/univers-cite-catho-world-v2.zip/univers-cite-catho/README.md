# Univers-Cité Catho — Konnaxion World Seed Pack v2.0.0

This pack is shaped after the **actual Konnaxion Worlds contract** (`kx-world-pack/v1`), not the custom UniverseSeed format used in the discarded v1 draft.

## Architecture

- **World:** `univers-cite-catho` (there is no artificial parent `world-konnaxion`).
- **Kristal:** canonical semantic/provenance source. Only stable concept identities and needed projections are materialized here.
- **UCKK:** owner of runtime courses. `bridges/uckk/course-blueprints.json` contains 16 curriculum blueprints, not duplicated Konnaxion courses.
- **Konnaxion modules:** native sidecars follow `kx-world-module-seed/v1` where possible.
- **ethiKos scenario:** valid v3 shape, question-only; no seeded stances, EkoH scores, votes or Smart Vote outcome.

## Four pathways

1. **Créer / Kreative** — arts, letters & culture.
2. **Comprendre / KonnectED** — humanities, sciences & tradition.
3. **Servir / keenKonnect** — applied sciences, professions & service institutions.
4. **Gouverner / ethiKos** — ethics, law & common good.

The pathways are **experience/navigation lenses**, not a new ontology and not copies of Kristal.

## Deliberate non-seeds

- Artist records are empty until Catholic affiliation and biographical provenance are explicitly sourced.
- Service-institution records are empty until Catholic affiliation and location are sourced.
- There are no preseeded certificates, evaluation attempts, EkoH scores, user stances, consultation votes or Smart Vote readings.

## Source provenance

Kristal source edition: `0.2.1`  
Kristal state: `sha256:5b5f48af42f5644d4d8817138c08f4f228832b364decd18cd830d0ad99a6ed93`  
Source ZIP SHA-256: `fbaa16f3a103b8980952b5eaf763dd0f128971fd342da7bd98ed08715e0418ca`

## Current bridge reality

The current Konnaxion Worlds builder automatically imports the declared ethiKos v3 scenario. Non-ethiKos module files in this pack are declarative sidecars/bridge seeds until the generic multi-module materializer imports them.

## Validation

Run:

```bash
python validate_pack.py
```

The validator checks the World contract shape, source/crosslink integrity, enum choices, duplicate keys and required v3 scenario structure.
