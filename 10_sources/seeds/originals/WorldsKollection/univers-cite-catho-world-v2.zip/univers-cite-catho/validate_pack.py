from pathlib import Path
import json, yaml, re, sys
ROOT=Path(__file__).resolve().parent
errors=[]
def err(x): errors.append(x)
world=yaml.safe_load((ROOT/'world.yaml').read_text(encoding='utf-8'))
if world.get('world_contract')!='kx-world-pack/v1': err('world_contract')
if not re.fullmatch(r'[a-z0-9][a-z0-9-]{1,62}[a-z0-9]', str(world.get('world_key',''))): err('world_key')
if not re.fullmatch(r'\d+\.\d+\.\d+',str(world.get('pack_version',''))): err('pack_version')
if not (world.get('requires') or {}).get('ethikos_scenario_schema'): err('requires.ethikos_scenario_schema')
scens=world.get('scenarios') or []
if not scens: err('scenarios empty')
required_scenario={'schema_version','scenario_key','scenario_title'}
list_roots={'actors','categories','topics','stances','arguments','argument_sources','consultations','consultation_votes','impact_items','ekoh_profiles','consultation_relevance','topic_relevance','reading_exclusions'}
for rel in scens:
 p=ROOT/rel
 if not p.is_file(): err(f'missing {rel}'); continue
 d=json.loads(p.read_text(encoding='utf-8'))
 if d.get('schema_version')!='ethikos-demo-scenario/v3': err(f'{rel}: schema_version')
 for k in required_scenario:
  if not d.get(k): err(f'{rel}: missing {k}')
 for k in list_roots:
  if not isinstance(d.get(k,[]),list): err(f'{rel}: {k} not list')
 cats={x.get('key') for x in d.get('categories',[])}
 for i,t in enumerate(d.get('topics',[])):
  if not {'key','title','status','category'} <= set(t): err(f'{rel}: topics[{i}] required')
  if t.get('status') not in {'open','closed','archived'}: err(f'{rel}: topics[{i}] status')
  if t.get('category') not in cats: err(f'{rel}: topics[{i}] category')
# Module integrity
course=json.loads((ROOT/'bridges/uckk/course-blueprints.json').read_text(encoding='utf-8'))['course_blueprints']
course_keys=[x['key'] for x in course]
if len(course_keys)!=len(set(course_keys)): err('duplicate course keys')
concepts=json.loads((ROOT/'canon/kristal-concepts.json').read_text(encoding='utf-8'))['concepts']
concept_refs={x['concept_ref'] for x in concepts}
for c in course:
 for ref in c['concept_refs']:
  if ref not in concept_refs: err(f'course {c["key"]}: unknown {ref}')
knowledge=json.loads((ROOT/'modules/knowledge/resources.json').read_text(encoding='utf-8'))
allowed={'article','video','lesson','quiz','dataset'}
for r in knowledge['resources']:
 if r['type'] not in allowed: err(f'Knowledge type {r["type"]}')
cert=json.loads((ROOT/'modules/certifikation/paths.json').read_text(encoding='utf-8'))
for p in cert['paths']:
 if p.get('pass_threshold_percent')!=80: err(f'Certification {p["key"]} threshold')
qbank=json.loads((ROOT/'modules/certifikation/assessment-bank.json').read_text(encoding='utf-8'))
qrefs={x['key'] for x in qbank['cases']}
for p in cert['paths']:
 for q in p.get('assessment_case_refs',[]):
  if q not in qrefs: err(f'Certification {p["key"]}: unknown assessment {q}')
cross=json.loads((ROOT/'modules/crosslinks.json').read_text(encoding='utf-8'))
for arc in cross['arcs']:
 for c in arc['uckk_course_refs']:
  if c not in course_keys: err(f'crosslink {arc["key"]}: unknown course {c}')
# Sensitive identity/affiliation seeds should remain absent in v2 base seed.
artists=json.loads((ROOT/'modules/kontact/artist-directory.json').read_text(encoding='utf-8'))
inst=json.loads((ROOT/'modules/keenkonnect/institutions.json').read_text(encoding='utf-8'))
if artists.get('records'): err('artist directory must be source-curated before base seed publication')
if inst.get('records'): err('institution directory must be source-curated before base seed publication')
if errors:
 print('INVALID')
 for e in errors: print('-',e)
 sys.exit(1)
print('VALID')
print('world_key:',world['world_key'])
print('pack_version:',world['pack_version'])
print('concepts:',len(concepts))
print('uckk_course_blueprints:',len(course))
print('assessment_cases:',len(qbank['cases']))
print('ethikos_topics:',len(json.loads((ROOT/scens[0]).read_text(encoding='utf-8'))['topics']))
