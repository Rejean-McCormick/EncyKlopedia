# Revision v1 → v2

The v1 draft is superseded.

| Area | v1 draft | v2 world pack |
|---|---|---|
| World model | invented parent `world-konnaxion` + child universe | `univers-cite-catho` is directly a Konnaxion World |
| Contract | custom `konnaxion.universe.seed.v1` | native `kx-world-pack/v1` |
| Lifecycle | portable custom seed | immutable Seed Pack → WorldRelease |
| Experience | pathways embedded as new domain structure | pathways in `experience.json` + `world.crosslinks` |
| Kristal | broad local projection | 99 concept identities only; positions remain canonical in Kristal |
| UCKK | implied course ownership | explicit external bridge with 16 blueprints; UCKK owns runtime courses |
| Knowledge | generic resource assumptions | current enum only: article/video/lesson/quiz/dataset |
| CertifiKation | counts/refs | 5 paths + source-preserving 57-case bank, 80% threshold |
| Kreative | conceptual artist surface | native Kontact/Konservation sidecars; no unsourced affiliation claims |
| keenKonnect | generic institution idea | explicit service-directory sidecar; materializer required instead of misusing Project |
| ethiKos | conceptual governance surface | valid v3 scenario with 15 sourced questions; no seeded stance/vote/reading |
| EkoH / Smart Vote | potential future use | no preseeded scores/results; derived-only policy |
| Cross-module wiring | implicit | one `modules/crosslinks.json` layer |

## Worlds used as design references

The revision follows patterns observed in the current Konnaxion repository, notably:

- `research-innovation-commons`: rich `world.yaml`, canon, module seeds and explicit bridge statuses;
- `ethikos-political-philosophy`: `experience.json`, home navigation, module visibility and crosslinks;
- `knowledge-continuity`: model mappings and explicit declarative bridge semantics;
- `operational-resilience-2026`: module policy and single-source-of-truth discipline;
- `levis-civic-simulation-2026`: multi-module sidecars and a dedicated crosslink layer;
- `uckk-a014`: useful minimal historical fixture, but intentionally not used as the rich-content template.
